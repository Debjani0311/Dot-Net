export const environment = {
  production: true,
  posturl:"https://localhost:44355/api",
};
