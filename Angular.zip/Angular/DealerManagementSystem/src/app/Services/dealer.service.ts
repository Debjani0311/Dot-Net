import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
@Injectable({
  providedIn: 'root'
})
export class DealerService {
  readonly environmenturl=environment.posturl;
  constructor(private http:HttpClient) { }
  Branddetails()
  {
    return this.http.get(this.environmenturl+'/Brand/GetBrandDetails')
  }
}





