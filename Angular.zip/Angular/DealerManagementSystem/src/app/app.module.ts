import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Core/header/header.component';
import { FooterComponent } from './Core/footer/footer.component';
import { BrandModule } from './Modules/brand/brand.module';
import { VechicleModule } from './Modules/vechicle/vechicle.module';
import { DealerModule } from './Modules/dealer/dealer.module';
import { HomesModule } from './Modules/homes/homes.module';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomesModule,
    BrandModule,
    VechicleModule,
    DealerModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
