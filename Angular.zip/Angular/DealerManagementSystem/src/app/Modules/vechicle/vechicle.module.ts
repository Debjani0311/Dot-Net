import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VechicleRoutingModule } from './vechicle-routing.module';
import { AddvechicleComponent } from './addvechicle/addvechicle.component';


@NgModule({
  declarations: [AddvechicleComponent],
  imports: [
    CommonModule,
    VechicleRoutingModule
  ]
})
export class VechicleModule { }
