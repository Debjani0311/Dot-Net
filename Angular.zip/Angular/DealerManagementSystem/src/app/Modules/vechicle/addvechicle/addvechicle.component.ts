import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addvechicle',
  templateUrl: './addvechicle.component.html',
  styleUrls: ['./addvechicle.component.css']
})
export class AddvechicleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
