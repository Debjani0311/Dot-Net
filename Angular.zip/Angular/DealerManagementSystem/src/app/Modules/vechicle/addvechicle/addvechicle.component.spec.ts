import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddvechicleComponent } from './addvechicle.component';

describe('AddvechicleComponent', () => {
  let component: AddvechicleComponent;
  let fixture: ComponentFixture<AddvechicleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddvechicleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddvechicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
