import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddvechicleComponent } from './addvechicle/addvechicle.component';

const routes: Routes = [
  {path:'addvechicle',component:AddvechicleComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VechicleRoutingModule { }
