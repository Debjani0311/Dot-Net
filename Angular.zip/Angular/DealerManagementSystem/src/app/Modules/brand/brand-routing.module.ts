import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddbrandComponent } from './addbrand/addbrand.component';


const routes: Routes = [
  {path:'addbrand',component:AddbrandComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BrandRoutingModule { }

