import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BrandRoutingModule } from './brand-routing.module';
import { AddbrandComponent } from './addbrand/addbrand.component';


@NgModule({
  declarations: [AddbrandComponent],
  imports: [
    CommonModule,
    BrandRoutingModule
  ]
})
export class BrandModule { }
