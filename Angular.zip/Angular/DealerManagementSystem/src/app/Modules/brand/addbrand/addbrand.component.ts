import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbrand',
  templateUrl: './addbrand.component.html',
  styleUrls: ['./addbrand.component.css']
})
export class AddbrandComponent implements OnInit {

  

  ngOnInit() {
  }

  constructor() { }
 

}
