import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adddealer',
  templateUrl: './adddealer.component.html',
  styleUrls: ['./adddealer.component.css']
})
export class AdddealerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
