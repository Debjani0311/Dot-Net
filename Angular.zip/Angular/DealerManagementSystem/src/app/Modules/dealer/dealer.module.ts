import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DealerRoutingModule } from './dealer-routing.module';
import { AdddealerComponent } from './adddealer/adddealer.component';


@NgModule({
  declarations: [AdddealerComponent],
  imports: [
    CommonModule,
    DealerRoutingModule
  ]
})
export class DealerModule { }
